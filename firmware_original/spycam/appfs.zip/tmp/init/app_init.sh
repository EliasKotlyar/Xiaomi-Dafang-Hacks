#!/bin/sh

#ifconfig eth0 193.169.4.175
#route add default gw 193.169.4.1

/system/init/start.sh
#insmod /system/lib/modules/tx-isp.ko
#insmod /system/lib/modules/sensor_jxh42.ko
/system/spdisk/xtipc_ctl &
/system/spdisk/ipsearch &

telnetd &
